from django.shortcuts import render
from django.http import HttpResponse
import joblib
import numpy as np
model=joblib.load('iris_data.sav')
def home(request):
    return render(request, 'index.html')
def about(request):
    return render(request, 'about.html')    
def nextpage(request):

    sl=float(request.GET['sepal length (cm)'])
    sw=float(request.GET['sepal width (cm)'])
    pl=float(request.GET['petal length (cm)'])
    pw=float(request.GET['petal width (cm)'])
    ans=[sl,sw,pl,pw]
    flower=np.array([ans])
    pred=model.predict(flower)
    if pred[0]==0:
        ans1="Flower is Iris-setosa"
    elif(pred[0]==1):
        ans1="Flower is Iris-versicolor"
    else:
        ans1="Flower is is Iris-virginica" 
    context={'ans1':ans1}    
    return render(request, 'nextpage.html',context)    
